﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Oppgave1Web.Model
{
    public class Bestilling
    {
        public int ID { get; set; }
        public string navn { get; set; }
        public string telefonnummer { get; set; }
        public string Avgang { get; set; }
    }
}

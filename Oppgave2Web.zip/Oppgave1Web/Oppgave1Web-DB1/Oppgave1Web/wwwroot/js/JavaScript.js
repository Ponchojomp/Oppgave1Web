﻿console.log("dette er en test");
